import { NextRequest, NextResponse } from "next/server";
import {
  areValidCredentials,
  AUTH_COOKIE,
  createSessionValue,
} from "@/lib/auth";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  let body: { username?: unknown; password?: unknown };

  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "INVALID_REQUEST" }, { status: 400 });
  }

  const username = typeof body.username === "string" ? body.username.trim() : "";
  const password = typeof body.password === "string" ? body.password : "";

  if (!areValidCredentials(username, password)) {
    return NextResponse.json(
      { error: "INVALID_CREDENTIALS" },
      { status: 401 }
    );
  }

  const dashboardUrl = process.env.DASHBOARD_URL || "https://firdhan-k3-agent.vercel.app/chat";
  const response = NextResponse.json({
    ok: true,
    redirectTo: `/splash?next=${encodeURIComponent(dashboardUrl)}`,
  });
  response.cookies.set(AUTH_COOKIE, createSessionValue(), {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  });

  return response;
}

export async function DELETE() {
  const response = NextResponse.json({ ok: true });
  response.cookies.set(AUTH_COOKIE, "", {
    httpOnly: true,
    expires: new Date(0),
    path: "/",
  });
  return response;
}