import ChatLayout from "@/components/chat/ChatLayout";

export const dynamic = "force-dynamic";

export default function ChatPage() {
  return <ChatLayout />;
}
