"use client";

import { FormEvent, useState, useEffect, useRef, useCallback } from "react";

const GLITCH_CHARS = "!@#$%^&*()_+-=[]{}|;:,.<>?/~`";

export default function LoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [typedText, setTypedText] = useState("");
  
  const shellRef = useRef<HTMLElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const particlesRef = useRef<HTMLDivElement>(null);
  const mousePos = useRef({ x: 0, y: 0 });

  const fullText = "Masukkan identitas operator untuk membuka ruang kerja terenkripsi.";

  // Typing effect
  useEffect(() => {
    let i = 0;
    const timer = setInterval(() => {
      if (i <= fullText.length) {
        setTypedText(fullText.slice(0, i));
        i++;
      } else {
        clearInterval(timer);
      }
    }, 35);
    return () => clearInterval(timer);
  }, []);

  // Matrix Rain Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener("resize", resize);

    const chars = "01アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン";
    const fontSize = 13;
    const columns = Math.floor(canvas.width / fontSize);
    const drops: number[] = Array(columns).fill(1);

    let animId: number;
    const draw = () => {
      ctx.fillStyle = "rgba(3, 4, 5, 0.045)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = "#00ff9c";
      ctx.font = `${fontSize}px "JetBrains Mono", monospace`;

      for (let i = 0; i < drops.length; i++) {
        const text = chars[Math.floor(Math.random() * chars.length)];
        ctx.globalAlpha = Math.random() * 0.4 + 0.15;
        ctx.fillText(text, i * fontSize, drops[i] * fontSize);
        if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
          drops[i] = 0;
        }
        drops[i]++;
      }
      ctx.globalAlpha = 1;
      animId = requestAnimationFrame(draw);
    };
    draw();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", resize);
    };
  }, []);

  // Parallax + 3D Tilt
  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!shellRef.current || !panelRef.current) return;
    const rect = shellRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left - rect.width / 2) / rect.width;
    const y = (e.clientY - rect.top - rect.height / 2) / rect.height;
    mousePos.current = { x, y };

    // Parallax layers
    const layers = shellRef.current.querySelectorAll<HTMLElement>(".parallax-layer");
    layers.forEach((layer) => {
      const speed = parseFloat(layer.dataset.speed || "0.03");
      layer.style.transform = `translate(${x * speed * 120}px, ${y * speed * 120}px)`;
    });

    // 3D tilt on panel
    const tiltX = y * -6;
    const tiltY = x * 6;
    panelRef.current.style.transform = `
      perspective(1200px)
      rotateX(${tiltX}deg)
      rotateY(${tiltY}deg)
      translateZ(10px)
    `;
  }, []);

  const handleMouseLeave = useCallback(() => {
    if (!shellRef.current || !panelRef.current) return;
    const layers = shellRef.current.querySelectorAll<HTMLElement>(".parallax-layer");
    layers.forEach((layer) => {
      layer.style.transform = "translate(0, 0)";
    });
    panelRef.current.style.transform = "perspective(1200px) rotateX(0deg) rotateY(0deg) translateZ(0)";
  }, []);

  useEffect(() => {
    const shell = shellRef.current;
    if (!shell) return;
    shell.addEventListener("mousemove", handleMouseMove);
    shell.addEventListener("mouseleave", handleMouseLeave);
    return () => {
      shell.removeEventListener("mousemove", handleMouseMove);
      shell.removeEventListener("mouseleave", handleMouseLeave);
    };
  }, [handleMouseMove, handleMouseLeave]);

  // Glitch effect on title
  useEffect(() => {
    const title = titleRef.current;
    if (!title) return;
    const original = title.dataset.text || "Operator access";
    
    const glitch = () => {
      if (Math.random() > 0.65) {
        const pos = Math.floor(Math.random() * original.length);
        const glitched =
          original.slice(0, pos) +
          GLITCH_CHARS[Math.floor(Math.random() * GLITCH_CHARS.length)] +
          original.slice(pos + 1);
        title.textContent = glitched;
        title.classList.add("active");
        setTimeout(() => {
          title.textContent = original;
          title.classList.remove("active");
        }, 90);
      }
      setTimeout(glitch, Math.random() * 2500 + 800);
    };
    const timer = setTimeout(glitch, 2000);
    return () => clearTimeout(timer);
  }, []);

  // Floating particles
  useEffect(() => {
    const container = particlesRef.current;
    if (!container) return;
    const colors = ["#00ff9c", "#bd3e24", "#00e5ff"];
    
    for (let i = 0; i < 20; i++) {
      const p = document.createElement("div");
      p.className = "particle";
      const size = Math.random() * 3 + 1;
      const color = colors[Math.floor(Math.random() * colors.length)];
      const duration = Math.random() * 5 + 4;
      const delay = Math.random() * 3;
      
      p.style.cssText = `
        width: ${size}px;
        height: ${size}px;
        background: ${color};
        left: ${Math.random() * 100}%;
        top: ${Math.random() * 100}%;
        opacity: ${Math.random() * 0.3 + 0.1};
        animation: float ${duration}s ease-in-out ${delay}s infinite,
                   particlePulse ${duration * 0.8}s ease-in-out ${delay}s infinite;
        box-shadow: 0 0 ${Math.random() * 8 + 3}px ${color};
      `;
      container.appendChild(p);
    }
    
    return () => { container.innerHTML = ""; };
  }, []);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setLoading(true);

    try {
      const response = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });

      if (!response.ok) {
        setError("Kredensial tidak valid. Periksa kembali ID dan password.");
        return;
      }

      const result = (await response.json()) as { redirectTo?: string };
      window.location.assign(result.redirectTo || "/chat");
    } catch {
      setError("Koneksi autentikasi gagal. Coba lagi.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main ref={shellRef} className="login-shell scanlines">
      <div className="login-noise" aria-hidden="true" />
      <canvas ref={canvasRef} className="matrix-canvas" aria-hidden="true" />
      
      {/* Parallax layers */}
      <div className="parallax-layer" data-speed="0.02" aria-hidden="true">
        <div style={{position:"absolute",top:"10%",left:"5%",width:"2px",height:"120px",background:"linear-gradient(to bottom,transparent,#00ff9c,transparent)",opacity:0.25}} />
        <div style={{position:"absolute",top:"60%",left:"80%",width:"2px",height:"200px",background:"linear-gradient(to bottom,transparent,#bd3e24,transparent)",opacity:0.2}} />
        <div style={{position:"absolute",top:"30%",left:"92%",width:"1px",height:"80px",background:"linear-gradient(to bottom,transparent,#00e5ff,transparent)",opacity:0.15}} />
        <div style={{position:"absolute",top:"80%",left:"15%",width:"1px",height:"150px",background:"linear-gradient(to bottom,transparent,#00ff9c,transparent)",opacity:0.18}} />
      </div>
      <div className="parallax-layer" data-speed="0.05" aria-hidden="true">
        <div style={{position:"absolute",top:"25%",left:"20%",width:"1px",height:"60px",background:"#00ff9c",opacity:0.12}} />
        <div style={{position:"absolute",top:"70%",left:"65%",width:"1px",height:"100px",background:"#bd3e24",opacity:0.1}} />
        <div style={{position:"absolute",top:"45%",left:"45%",width:"1px",height:"45px",background:"#00e5ff",opacity:0.08}} />
      </div>
      <div className="parallax-layer" data-speed="0.08" aria-hidden="true">
        <div style={{position:"absolute",top:"15%",left:"60%",width:"1px",height:"30px",background:"#bd3e24",opacity:0.1}} />
        <div style={{position:"absolute",top:"85%",left:"30%",width:"1px",height:"50px",background:"#00ff9c",opacity:0.08}} />
      </div>

      {/* Floating particles */}
      <div ref={particlesRef} className="particles-container" aria-hidden="true" />

      {/* Agent & Orbits */}
      <div className="login-agent" aria-hidden="true">
        <div className="agent-hat"><span /></div>
        <div className="agent-head"><i /><i /></div>
        <div className="agent-coat" />
      </div>
      <div className="login-orbit login-orbit-one" aria-hidden="true" />
      <div className="login-orbit login-orbit-two" aria-hidden="true" />

      {/* Main Panel */}
      <section ref={panelRef} className="login-panel" aria-labelledby="login-title">
        <div className="login-status">
          <span className="status-dot" aria-hidden="true" />
          BLACKHAT NETWORK ACCESS
        </div>

        <div className="login-brand">
          <span className="login-mark">K3<span>_</span></span>
          <div>
            <p className="login-kicker">K3 F34RD0WN CYBER INTELLIGENCE</p>
            <h1
              id="login-title"
              ref={titleRef}
              className="glitch-text"
              data-text="Operator access"
            >
              Operator access
            </h1>
          </div>
        </div>

        <p className="login-copy typing-cursor">
          {typedText}
        </p>

        <div className="login-rule"><span /> AUTHORIZATION REQUIRED <span /></div>

        <form onSubmit={submit} className="login-form">
          <label htmlFor="username">USER ID</label>
          <input
            id="username"
            name="username"
            autoComplete="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="USER1_USER"
            required
          />

          <label htmlFor="password">ACCESS KEY</label>
          <input
            id="password"
            name="password"
            type="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="USER1_PASS"
            required
          />

          {error && <p className="login-error" role="alert">{error}</p>}

          <button type="submit" disabled={loading}>
            <span>{loading ? "VERIFYING..." : "CONNECT TO DASHBOARD"}</span>
            <span aria-hidden="true">[ ENTER ]</span>
          </button>
        </form>

        <div className="login-meta">
          <p><span className="status-dot" aria-hidden="true" /> SESSION ENCRYPTION: ACTIVE</p>
          <p>NODE: 07 / AES-256</p>
        </div>
      </section>

      <p className="login-coordinates" aria-hidden="true">
        34.0522 N / 118.2437 W<br />SIGNAL: ENCRYPTED
      </p>
    </main>
  );
}
