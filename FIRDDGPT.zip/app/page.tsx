import { redirect } from "next/navigation";

/** Home → straight into the chatbot. This is a chat application, not a landing page. */
export default function Home() {
  redirect("/chat");
}
