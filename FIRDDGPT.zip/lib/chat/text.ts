/**
 * Repairs accidental token/word duplication produced by some streaming
 * providers, e.g. `importimport`, `elifelif`, `returnreturn`.
 *
 * Important: this function is intended to run on the COMPLETE accumulated
 * response (or on a complete UI snapshot), not independently on each
 * streaming chunk. Repairing individual chunks can corrupt tokens that are
 * split across chunk boundaries.
 */
export function repairRepeatedTokens(value: string): string {
  if (!value) return value;

  let repaired = value;

  // Collapse directly duplicated identifier-like words:
  // importimport -> import, returnreturn -> return, etc.
  // Requiring an identifier boundary on both sides avoids changing normal
  // words such as "committee" or "success".
  repaired = repaired.replace(
    /\b([A-Za-z_$][A-Za-z0-9_$]{1,})(?:\1)+\b/g,
    "$1"
  );

  // Same protection for numeric literals accidentally duplicated.
  repaired = repaired.replace(
    /\b(\d+(?:\.\d+)?)(?:\1)+\b/g,
    "$1"
  );

  // A few providers duplicate an entire quoted/code token.
  repaired = repaired.replace(
    /(["'`])([^\r\n]*?)\1\1\2\1/g,
    "$1$2$1"
  );

  // Collapse an accidentally duplicated complete line, but only when the
  // two halves are exactly identical. This is intentionally conservative.
  repaired = repaired.replace(/^([ \t]*)([^\r\n]{16,})$/gm, (line, indent, body) => {
    if (body.length % 2 !== 0) return line;
    const midpoint = body.length / 2;
    return body.slice(0, midpoint) === body.slice(midpoint)
      ? `${indent}${body.slice(0, midpoint)}`
      : line;
  });

  return repaired;
}

/**
 * Append a provider chunk without re-appending cumulative or repeated chunks.
 */
export function appendStreamText(current: string, chunk: string): string {
  if (!chunk) return current;
  if (!current) return chunk;
  if (chunk.startsWith(current)) return chunk;
  if (current.endsWith(chunk) && chunk.trim().length >= 3) return current;
  return current + chunk;
}
